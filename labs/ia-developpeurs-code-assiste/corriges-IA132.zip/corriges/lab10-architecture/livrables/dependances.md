# Analyse des dépendances du prototype 2019

Analyse proposée par l’IA, **vérifiée** avec `pip-audit -r requirements-legacy.txt` et `npm audit` (base GitHub Advisory / OSV). Les identifiants CVE cités par l’IA ont été contrôlés un par un ; ceux qui n’existaient pas ont été retirés.

## Python

| Paquet | Version | Constat | Action |
| --- | --- | --- | --- |
| Django | 2.2.0 | Branche en fin de vie depuis avril 2022, nombreuses failles corrigées depuis | Migrer vers la version LTS courante |
| requests | 2.19.1 | CVE-2018-18074 (en-tête Authorization envoyé après redirection vers HTTP) | ≥ dernière version |
| urllib3 | 1.24.1 | CVE-2019-11324 (validation des certificats) | Suit la mise à jour de requests |
| PyYAML | 5.3 | CVE-2020-14343 (exécution de code via `full_load`) | ≥ 5.4, et `safe_load` uniquement |
| Jinja2 | 2.10 | CVE-2019-10906 (évasion du bac à sable) | Version 3.x |
| Pillow | 8.0.0 | Plusieurs failles de décodage d’images | Dernière version |
| celery | 4.3.0 | Ancienne branche, non maintenue | 5.x, ou retirer si la file de messages suffit |

## JavaScript

| Paquet | Version | Constat | Action |
| --- | --- | --- | --- |
| lodash | 4.17.15 | CVE-2020-8203 (pollution de prototype) | ≥ 4.17.21, ou méthodes natives |
| axios | 0.21.0 | CVE-2020-28168 (SSRF via redirection) | 1.x |
| jsonwebtoken | 8.5.1 | CVE-2022-23529 et failles corrigées en 9.0.0 | ≥ 9 |
| moment | 2.29.1 | CVE-2022-24785 ; bibliothèque en mode maintenance | `Intl` / `Temporal`, ou date-fns |
| express | 4.16.0 | Dépendances transitives vulnérables | Dernière 4.x ou 5.x |
| request | 2.88.0 | Paquet abandonné (2020) | `fetch` natif |

## Recommandation

Ne pas réutiliser ces fichiers : repartir des versions courantes et ajouter `pip-audit` et `npm audit --audit-level=high` au pipeline CI pour bloquer toute régression.
